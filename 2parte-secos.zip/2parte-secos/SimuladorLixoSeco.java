import java.util.Scanner;

import modelo.LixoSeco;
import serviços.ReEnSec;
import serviços.ConEnSec;

public class SimuladorLixoSeco {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Lê Massa de Madeira
        double madeira = obterEntradaValida(sc, "Massa de Madeira (kg): ");

        // Lê Massa de Tecidos
        double tecidos = obterEntradaValida(sc, "Massa de Tecidos (kg): ");

        // Lê Massa de Papeis
        double papeis = obterEntradaValida(sc, "Massa de Papeis (kg): ");

        // Lê Eficiência da queima
        double eficiencia = obterEntradaValida(sc, "Eficiência da queima (0 a 1): ");

        // Cria e calcula energias
        LixoSeco ls = new LixoSeco(madeira, tecidos, papeis, eficiencia);
        ls.calcularEnergias();

        // Exibe o relatório
        ConEnSec ces = new ConEnSec();
        ReEnSec res = new ReEnSec(ls, ces);
        res.relatorio();

        sc.close();
    }

    // Função para obter entrada válida de números
    private static double obterEntradaValida(Scanner sc, String mensagem) {
        double valor = 0;
        boolean entradaValida = false;
        while (!entradaValida) {
            try {
                System.out.print(mensagem);
                String input = sc.nextLine().replace(',', '.'); // Substitui a vírgula pelo ponto
                valor = Double.parseDouble(input);  // Tenta converter para double
                entradaValida = true; // Se for bem-sucedido, sai do loop
            } catch (NumberFormatException e) {
                System.out.println("Valor inválido. Tente novamente.");
            }
        }
        return valor;
    }
}
